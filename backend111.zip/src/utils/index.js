// src/utils/index.js
module.exports = {
  ...require('./securityLogger'),
  ...require('./rateLimiter'),
  // outros utilitários
};