# Guia de Instalação do Sistema de Gerenciamento de Receitas Médicas

Este guia fornece instruções detalhadas para instalar e configurar o sistema de gerenciamento de receitas médicas em diferentes ambientes.

## Requisitos do Sistema

- Node.js 14.x ou superior
- MongoDB 4.x ou superior
- Servidor web (Nginx recomendado para produção)

## Estrutura do Projeto

O sistema é composto por:

- **Backend**: API REST em Node.js/Express
- **Frontend**: Interface de usuário em React
- **Documentação**: Manuais e guias de uso
- **Scripts de Implantação**: Para diferentes ambientes

## Instalação do Backend

1. Navegue até o diretório do backend:
   ```bash
   cd backend
   ```

2. Instale as dependências:
   ```bash
   npm install
   ```

3. Configure as variáveis de ambiente:
   ```bash
   cp .env.example .env
   ```

4. Edite o arquivo `.env` com suas configurações:
   ```
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/sistema_receitas
   JWT_SECRET=sua_chave_secreta
   EMAIL_USER=seu_email@gmail.com
   EMAIL_PASS=sua_senha_de_app
   ```

5. Inicie o servidor:
   ```bash
   npm start
   ```

## Instalação do Frontend

1. Navegue até o diretório do frontend:
   ```bash
   cd frontend/receitas-web
   ```

2. Instale as dependências:
   ```bash
   npm install
   ```

3. Configure a URL da API:
   Edite o arquivo `src/services/api.js` se necessário para apontar para o endereço correto do backend.

4. Inicie o servidor de desenvolvimento:
   ```bash
   npm start
   ```

5. Para build de produção:
   ```bash
   npm run build
   ```

## Opções de Implantação

### Implantação Local

Para implantação em ambiente local ou servidor próprio:

```bash
cd deploy
./setup_local.sh
```

### Implantação no Vercel

Para implantação rápida no Vercel:

```bash
cd deploy
./setup_vercel.sh
```

### Implantação no Netlify

Para implantação rápida no Netlify:

```bash
cd deploy
./setup_netlify.sh
```

### Configuração de Domínio

Para configurar o domínio receitas.paulodonadel.com.br:

```bash
cd deploy
./setup_domain.sh
```

## Contas Pré-configuradas

- **Administrador**: paulodonadel / 215736
- **Secretária**: secretaria / 1926
- **Paciente (demo)**: paciente / 123456

## Suporte

Para qualquer dúvida ou problema durante a instalação, entre em contato com o suporte técnico.
