import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Box, 
  Typography, 
  Paper, 
  Grid,
  Card,
  CardContent,
  Button,
  Divider,
  List,
  ListItem,
  ListItemText,
  Chip,
  CircularProgress,
  Alert
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import prescriptionService from '../../services/prescriptionService';

// Componentes estilizados
const DashboardPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  marginBottom: theme.spacing(3),
}));

const StatCard = styled(Card)(({ theme }) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
}));

const StatValue = styled(Typography)(({ theme }) => ({
  fontSize: '2.5rem',
  fontWeight: 'bold',
  color: theme.palette.primary.main,
}));

const Dashboard = () => {
  const { user } = useAuth();
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Buscar prescrições do usuário
  useEffect(() => {
    const fetchPrescriptions = async () => {
      try {
        setLoading(true);
        const response = await prescriptionService.getMyPrescriptions();
        
        if (response.success) {
          setPrescriptions(response.data);
        } else {
          throw new Error(response.message || 'Erro ao buscar prescrições');
        }
      } catch (err) {
        console.error('Erro ao buscar prescrições:', err);
        setError('Não foi possível carregar suas prescrições. Por favor, tente novamente mais tarde.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchPrescriptions();
  }, []);
  
  // Estatísticas
  const pendingCount = prescriptions.filter(p => 
    p.status === 'solicitada' || p.status === 'em_analise'
  ).length;
  
  const approvedCount = prescriptions.filter(p => 
    p.status === 'aprovada'
  ).length;
  
  const readyCount = prescriptions.filter(p => 
    p.status === 'pronta' || p.status === 'enviada'
  ).length;
  
  const totalCount = prescriptions.length;
  
  // Função para obter a cor do status
  const getStatusColor = (status) => {
    switch(status) {
      case 'solicitada': return 'warning';
      case 'em_analise': return 'warning';
      case 'aprovada': return 'info';
      case 'pronta': return 'success';
      case 'enviada': return 'success';
      case 'rejeitada': return 'error';
      default: return 'default';
    }
  };
  
  // Função para obter o texto do status
  const getStatusText = (status) => {
    switch(status) {
      case 'solicitada': return 'Solicitada';
      case 'em_analise': return 'Em análise';
      case 'aprovada': return 'Aprovada';
      case 'pronta': return 'Pronta para retirada';
      case 'enviada': return 'Enviada';
      case 'rejeitada': return 'Rejeitada';
      default: return status;
    }
  };
  
  // Função para obter o texto do tipo de receituário
  const getPrescriptionTypeText = (type) => {
    switch(type) {
      case 'branco': return 'Branco';
      case 'azul': return 'Azul';
      case 'amarelo': return 'Amarelo';
      default: return type;
    }
  };
  
  // Função para obter o texto do método de entrega
  const getDeliveryMethodText = (method, type) => {
    if (method === 'email' && type === 'branco') {
      return 'Envio por e-mail';
    } else {
      return 'Retirada na clínica (5 dias úteis)';
    }
  };
  
  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Dashboard do Paciente
        </Typography>
        
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <StatCard>
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Pendentes
                </Typography>
                <StatValue>{loading ? <CircularProgress size={30} /> : pendingCount}</StatValue>
              </CardContent>
            </StatCard>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <StatCard>
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Aprovadas
                </Typography>
                <StatValue>{loading ? <CircularProgress size={30} /> : approvedCount}</StatValue>
              </CardContent>
            </StatCard>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <StatCard>
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Prontas
                </Typography>
                <StatValue>{loading ? <CircularProgress size={30} /> : readyCount}</StatValue>
              </CardContent>
            </StatCard>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <StatCard>
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Total
                </Typography>
                <StatValue>{loading ? <CircularProgress size={30} /> : totalCount}</StatValue>
              </CardContent>
            </StatCard>
          </Grid>
        </Grid>
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <DashboardPaper elevation={2}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">
                  Suas Solicitações
                </Typography>
                <Button 
                  component={Link} 
                  to="/patient/request" 
                  variant="contained" 
                  color="primary"
                >
                  Nova Solicitação
                </Button>
              </Box>
              
              <Divider sx={{ mb: 2 }} />
              
              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress />
                </Box>
              ) : error ? (
                <Alert severity="error" sx={{ mb: 2 }}>
                  {error}
                </Alert>
              ) : prescriptions.length > 0 ? (
                <List>
                  {prescriptions.slice(0, 5).map((prescription) => (
                    <React.Fragment key={prescription._id}>
                      <ListItem 
                        component={Paper} 
                        elevation={1} 
                        sx={{ mb: 1, p: 2 }}
                      >
                        <Grid container spacing={2}>
                          <Grid item xs={12} sm={6}>
                            <ListItemText 
                              primary={prescription.medicationName} 
                              secondary={`Receituário ${getPrescriptionTypeText(prescription.prescriptionType)}`}
                            />
                          </Grid>
                          <Grid item xs={12} sm={3}>
                            <Typography variant="body2" color="text.secondary">
                              Solicitada em: {new Date(prescription.createdAt).toLocaleDateString('pt-BR')}
                            </Typography>
                            <Typography variant="body2">
                              {getDeliveryMethodText(prescription.deliveryMethod, prescription.prescriptionType)}
                            </Typography>
                          </Grid>
                          <Grid item xs={12} sm={3} sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
                            <Chip 
                              label={getStatusText(prescription.status)} 
                              color={getStatusColor(prescription.status)}
                              sx={{ fontWeight: 'bold' }}
                            />
                          </Grid>
                        </Grid>
                      </ListItem>
                    </React.Fragment>
                  ))}
                </List>
              ) : (
                <Typography variant="body1" align="center" sx={{ py: 4 }}>
                  Você ainda não tem solicitações de receitas.
                </Typography>
              )}
              
              <Box sx={{ mt: 2, display: 'flex', justifyContent: 'center' }}>
                <Button 
                  component={Link} 
                  to="/patient/status" 
                  variant="outlined" 
                  color="primary"
                >
                  Ver Todas as Solicitações
                </Button>
              </Box>
            </DashboardPaper>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <DashboardPaper elevation={2}>
              <Typography variant="h6" gutterBottom>
                Informações Importantes
              </Typography>
              
              <Divider sx={{ mb: 2 }} />
              
              <Typography variant="subtitle1" gutterBottom>
                Prazos:
              </Typography>
              <Typography variant="body2" paragraph>
                • Todas as receitas estarão disponíveis em até 5 dias úteis após aprovação.
              </Typography>
              <Typography variant="body2" paragraph>
                • Receitas são geralmente preparadas às quintas-feiras.
              </Typography>
              
              <Typography variant="subtitle1" gutterBottom>
                Tipos de Receituários:
              </Typography>
              <Typography variant="body2" paragraph>
                • <strong>Branco:</strong> Medicamentos de uso contínuo não controlados. Podem ser enviados por e-mail ou retirados na clínica.
              </Typography>
              <Typography variant="body2" paragraph>
                • <strong>Azul:</strong> Medicamentos controlados da lista B. Devem ser retirados na clínica.
              </Typography>
              <Typography variant="body2" paragraph>
                • <strong>Amarelo:</strong> Medicamentos controlados da lista A. Devem ser retirados na clínica.
              </Typography>
              
              <Typography variant="subtitle1" gutterBottom>
                Frequência:
              </Typography>
              <Typography variant="body2">
                • Solicitações podem ser feitas uma vez por mês para cada medicamento.
              </Typography>
            </DashboardPaper>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default Dashboard;
