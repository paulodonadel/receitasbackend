import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Box, 
  Typography, 
  Paper, 
  Grid,
  Card,
  CardContent,
  Button,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  TextField,
  InputAdornment,
  IconButton,
  Tabs,
  Tab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { styled } from '@mui/material/styles';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import { useAuth } from '../../hooks/useAuth';

// Componentes estilizados
const ManagePaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  marginBottom: theme.spacing(3),
}));

// Dados simulados para demonstração
const mockPrescriptions = [
  { 
    id: '1', 
    patientName: 'João Silva',
    patientCPF: '123.456.789-00',
    medicationName: 'Fluoxetina', 
    requestDate: '2025-04-20', 
    status: 'pending',
    type: 'white',
    deliveryMethod: 'email',
    email: 'joao.silva@email.com',
    address: 'Rua das Flores, 123',
    zipCode: '90000-000'
  },
  { 
    id: '2', 
    patientName: 'Maria Oliveira',
    patientCPF: '987.654.321-00',
    medicationName: 'Clonazepam', 
    requestDate: '2025-04-15', 
    status: 'approved',
    type: 'blue',
    deliveryMethod: 'pickup'
  },
  { 
    id: '3', 
    patientName: 'Carlos Santos',
    patientCPF: '456.789.123-00',
    medicationName: 'Sertralina', 
    requestDate: '2025-04-10', 
    status: 'ready',
    type: 'white',
    deliveryMethod: 'pickup'
  },
  { 
    id: '4', 
    patientName: 'Ana Pereira',
    patientCPF: '789.123.456-00',
    medicationName: 'Risperidona', 
    requestDate: '2025-04-05', 
    status: 'pending',
    type: 'yellow',
    deliveryMethod: 'pickup'
  },
  { 
    id: '5', 
    patientName: 'Roberto Almeida',
    patientCPF: '321.654.987-00',
    medicationName: 'Escitalopram', 
    requestDate: '2025-04-01', 
    status: 'approved',
    type: 'white',
    deliveryMethod: 'email',
    email: 'roberto.almeida@email.com',
    address: 'Av. Principal, 456',
    zipCode: '90000-001'
  }
];

const ManagePrescriptions = () => {
  const { user } = useAuth();
  const [prescriptions, setPrescriptions] = useState(mockPrescriptions);
  const [searchTerm, setSearchTerm] = useState('');
  const [tabValue, setTabValue] = useState(0);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedPrescription, setSelectedPrescription] = useState<any>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [statusUpdateType, setStatusUpdateType] = useState('');
  
  // Estatísticas
  const pendingCount = prescriptions.filter(p => p.status === 'pending').length;
  const approvedCount = prescriptions.filter(p => p.status === 'approved').length;
  const readyCount = prescriptions.filter(p => p.status === 'ready').length;
  const totalCount = prescriptions.length;
  
  // Função para obter a cor do status
  const getStatusColor = (status: string) => {
    switch(status) {
      case 'pending': return 'warning';
      case 'approved': return 'info';
      case 'ready': return 'success';
      case 'rejected': return 'error';
      default: return 'default';
    }
  };
  
  // Função para obter o texto do status
  const getStatusText = (status: string) => {
    switch(status) {
      case 'pending': return 'Pendente';
      case 'approved': return 'Aprovada';
      case 'ready': return 'Pronta para retirada';
      case 'rejected': return 'Rejeitada';
      default: return status;
    }
  };
  
  // Função para obter o texto do tipo de receituário
  const getPrescriptionTypeText = (type: string) => {
    switch(type) {
      case 'white': return 'Branco';
      case 'blue': return 'Azul';
      case 'yellow': return 'Amarelo';
      default: return type;
    }
  };
  
  // Função para obter o texto do método de entrega
  const getDeliveryMethodText = (method: string, type: string) => {
    if (method === 'email' && type === 'white') {
      return 'Envio por e-mail';
    } else {
      return 'Retirada na clínica (5 dias úteis)';
    }
  };
  
  // Filtrar receitas com base na aba selecionada
  const getFilteredPrescriptions = () => {
    let filtered = [...prescriptions];
    
    // Filtrar por termo de busca
    if (searchTerm) {
      filtered = filtered.filter(p => 
        p.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.medicationName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.patientCPF.includes(searchTerm)
      );
    }
    
    // Filtrar por status (aba)
    if (tabValue === 1) {
      filtered = filtered.filter(p => p.status === 'pending');
    } else if (tabValue === 2) {
      filtered = filtered.filter(p => p.status === 'approved');
    } else if (tabValue === 3) {
      filtered = filtered.filter(p => p.status === 'ready');
    } else if (tabValue === 4) {
      filtered = filtered.filter(p => p.status === 'rejected');
    }
    
    return filtered;
  };
  
  // Função para abrir diálogo de aprovação
  const handleOpenApproveDialog = (prescription: any) => {
    setSelectedPrescription(prescription);
    setStatusUpdateType('approve');
    setOpenDialog(true);
  };
  
  // Função para abrir diálogo de rejeição
  const handleOpenRejectDialog = (prescription: any) => {
    setSelectedPrescription(prescription);
    setStatusUpdateType('reject');
    setRejectReason('');
    setOpenDialog(true);
  };
  
  // Função para abrir diálogo de marcar como pronta
  const handleOpenMarkAsReadyDialog = (prescription: any) => {
    setSelectedPrescription(prescription);
    setStatusUpdateType('ready');
    setOpenDialog(true);
  };
  
  // Função para fechar diálogo
  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedPrescription(null);
    setRejectReason('');
    setStatusUpdateType('');
  };
  
  // Função para confirmar atualização de status
  const handleConfirmStatusUpdate = () => {
    if (!selectedPrescription) return;
    
    const updatedPrescriptions = prescriptions.map(p => {
      if (p.id === selectedPrescription.id) {
        if (statusUpdateType === 'approve') {
          return { ...p, status: 'approved' };
        } else if (statusUpdateType === 'reject') {
          return { ...p, status: 'rejected', rejectionReason: rejectReason };
        } else if (statusUpdateType === 'ready') {
          return { ...p, status: 'ready' };
        }
      }
      return p;
    });
    
    setPrescriptions(updatedPrescriptions);
    handleCloseDialog();
  };
  
  // Função para lidar com a mudança de aba
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };
  
  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Gerenciamento de Receitas
        </Typography>
        
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Pendentes
                </Typography>
                <Typography variant="h3" color="warning.main">
                  {pendingCount}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Aprovadas
                </Typography>
                <Typography variant="h3" color="info.main">
                  {approvedCount}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Prontas
                </Typography>
                <Typography variant="h3" color="success.main">
                  {readyCount}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Total
                </Typography>
                <Typography variant="h3" color="primary.main">
                  {totalCount}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        
        <ManagePaper elevation={2}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">
              Lista de Receitas
            </Typography>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <TextField
                placeholder="Buscar por paciente, medicamento ou CPF"
                size="small"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
                sx={{ width: 300 }}
              />
              <IconButton>
                <FilterListIcon />
              </IconButton>
            </Box>
          </Box>
          
          <Tabs value={tabValue} onChange={handleTabChange} sx={{ mb: 2 }}>
            <Tab label="Todas" />
            <Tab label="Pendentes" />
            <Tab label="Aprovadas" />
            <Tab label="Prontas" />
            <Tab label="Rejeitadas" />
          </Tabs>
          
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Paciente</TableCell>
                  <TableCell>CPF</TableCell>
                  <TableCell>Medicamento</TableCell>
                  <TableCell>Tipo</TableCell>
                  <TableCell>Data</TableCell>
                  <TableCell>Entrega</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Ações</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {getFilteredPrescriptions().map((prescription) => (
                  <TableRow key={prescription.id}>
                    <TableCell>{prescription.patientName}</TableCell>
                    <TableCell>{prescription.patientCPF}</TableCell>
                    <TableCell>{prescription.medicationName}</TableCell>
                    <TableCell>{getPrescriptionTypeText(prescription.type)}</TableCell>
                    <TableCell>{new Date(prescription.requestDate).toLocaleDateString('pt-BR')}</TableCell>
                    <TableCell>{getDeliveryMethodText(prescription.deliveryMethod, prescription.type)}</TableCell>
                    <TableCell>
                      <Chip 
                        label={getStatusText(prescription.status)} 
                        color={getStatusColor(prescription.status) as any}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>
                      {prescription.status === 'pending' && (
                        <Box sx={{ display: 'flex', gap: 1 }}>
                          <Button 
                            variant="outlined" 
                            color="primary" 
                            size="small"
                            onClick={() => handleOpenApproveDialog(prescription)}
                          >
                            Aprovar
                          </Button>
                          <Button 
                            variant="outlined" 
                            color="error" 
                            size="small"
                            onClick={() => handleOpenRejectDialog(prescription)}
                          >
                            Rejeitar
                          </Button>
                        </Box>
                      )}
                      {prescription.status === 'approved' && (
                        <Button 
                          variant="outlined" 
                          color="success" 
                          size="small"
                          onClick={() => handleOpenMarkAsReadyDialog(prescription)}
                        >
                          Marcar como Pronta
                        </Button>
                      )}
                      {(prescription.status === 'ready' || prescription.status === 'rejected') && (
                        <Typography variant="body2" color="text.secondary">
                          Nenhuma ação disponível
                        </Typography>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          
          {getFilteredPrescriptions().length === 0 && (
            <Box sx={{ py: 4, textAlign: 'center' }}>
              <Typography variant="body1">
                Nenhuma receita encontrada.
              </Typography>
            </Box>
          )}
        </ManagePaper>
      </Box>
      
      {/* Diálogo de confirmação */}
      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>
          {statusUpdateType === 'approve' && 'Aprovar Receita'}
          {statusUpdateType === 'reject' && 'Rejeitar Receita'}
          {statusUpdateType === 'ready' && 'Marcar Receita como Pronta'}
        </DialogTitle>
        <DialogContent>
          {selectedPrescription && (
            <>
              <DialogContentText>
                {statusUpdateType === 'approve' && 'Você está prestes a aprovar a receita de:'}
                {statusUpdateType === 'reject' && 'Você está prestes a rejeitar a receita de:'}
                {statusUpdateType === 'ready' && 'Você está prestes a marcar como pronta a receita de:'}
              </DialogContentText>
              
              <Box sx={{ mt: 2, mb: 3 }}>
                <Typography variant="subtitle1">
                  {selectedPrescription.patientName}
                </Typography>
                <Typography variant="body2">
                  Medicamento: {selectedPrescription.medicationName}
                </Typography>
                <Typography variant="body2">
                  Tipo: {getPrescriptionTypeText(selectedPrescription.type)}
                </Typography>
                <Typography variant="body2">
                  Entrega: {getDeliveryMethodText(selectedPrescription.deliveryMethod, selectedPrescription.type)}
                </Typography>
              </Box>
              
              {statusUpdateType === 'reject' && (
                <TextField
                  autoFocus
                  margin="dense"
                  id="reason"
                  label="Motivo da rejeição"
                  type="text"
                  fullWidth
                  multiline
                  rows={3}
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                />
              )}
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancelar</Button>
          <Button 
            onClick={handleConfirmStatusUpdate} 
            color={
              statusUpdateType === 'approve' ? 'primary' : 
              statusUpdateType === 'reject' ? 'error' : 'success'
            }
            variant="contained"
            disabled={statusUpdateType === 'reject' && !rejectReason}
          >
            Confirmar
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default ManagePrescriptions;
